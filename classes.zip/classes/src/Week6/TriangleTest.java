package Week6;

public class TriangleTest {
    public static void main(String[] args) {
        Triangle tri = new Triangle(5,10);
        tri.calculateArea();
        tri.printArea();
    }
}
