public class Main {

    public static void main(String[] args) {
        StudentSet studentSet = new StudentSet();

        // Add students
        studentSet.addStudents();

        // Display students
        studentSet.displayStudents();
    }
}
