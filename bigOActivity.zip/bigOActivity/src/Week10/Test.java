package Week10;

public class Test {
    public static void main(String[] args) {
        BigO bigO = new BigO();

        bigO.printOnce("Solomon");
        bigO.printNTimes(2);
        bigO.printNSquaredTimes(4);
    }
}
